Tim Beckman Music — Static React Site (Squarespace domain)

Files
- index.html               → single-file React app (Tailwind via CDN)
- assets/tb-anchor.png     → TB anchor logo (transparent)
- assets/tim-katie.png     → Tim & Katie logo (lighter navy)
- assets/boathouse.png     → Boathouse logo (current/placeholder)
- vercel.json              → if you deploy to Vercel as static hosting

Local Preview
1) Open index.html in your browser (double-click).
2) Ensure the assets/ folder sits alongside index.html with the 3 PNGs.

Using Squarespace Domain with External Hosting (Vercel/Netlify)
1) Deploy this folder to Vercel (vercel.com/new) or Netlify (app.netlify.com/drop).
2) In Squarespace: Settings → Domains → your domain → DNS Settings.
3) Add either:
   - A record: @ → 76.76.21.21 (Vercel)  OR
   - CNAME: www → cname.vercel-dns.com
4) Save. Propagation usually completes in 5–30 minutes.
